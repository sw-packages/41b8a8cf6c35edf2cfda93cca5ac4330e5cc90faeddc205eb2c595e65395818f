// Copyright (C) 2018 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

//! [0]
static const auto matcher = qMakeStaticByteArrayMatcher("needle");
//! [0]

//! [1]
static const auto matcher = qMakeStaticByteArrayMatcher("needle");
//! [1]
